import { LightningElement } from 'lwc';
import firsthtml from './sampleComponent.html';
import secondhtml from './sample2.html';
import thirdhtml from './sample3.html';

export default class SampleComponent extends LightningElement {

greeting;
template='first';

connectedCallback(){
    console.log('Connected Callback Ran');
}
constructor(){
    super();
    this.greeting = 'Good Morning';
    console.log('Constructor Loaded');
    this.template='first';
}

renderedCallback(){
    console.log('Rendered Callback Ran');
}

handleClick(){
    console.log('Inside click');
    if (this.greeting ==='Good Morning'){
        this.greeting = 'Good Afternoon';
    }else{
        this.greeting = 'Good Morning';
    }
}

handleTemplate(){
    if(this.template ==='first'){
        this.template ='second';
        }else if(this.template==='second'){
            this.template='third';
        }else if(this.template==='third'){
            this.template='first';
        }
}

render(){
    console.log('Render Ran');
    if(this.template ==='first'){
        return firsthtml;
    }else if(this.template==='second'){
        return secondhtml;
    }else if(this.template==='third'){
        return thirdhtml;
    }
}


}


