import { LightningElement, wire, track } from 'lwc';
import fetchAccounts from '@salesforce/apex/ExampleController.fetchAccounts';


export default class SampleAccount extends LightningElement {

    @track accounts;
   
    @wire( fetchAccounts ) 
    caseRecord({ error, data }) { 
 
        if ( data ) { 
 
            this.accounts = data; 
 
        } else if ( error )
            console.log( 'Error is ' + JSON.stringify( error ) );
         
    }

}
