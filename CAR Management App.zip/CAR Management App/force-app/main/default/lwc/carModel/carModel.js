import { LightningElement,wire,track } from 'lwc';
import carModel from '@salesforce/apex/CarRecordController.getAccounts';

export default class CarModel extends LightningElement {

@track data;
@wire(carModel) accountRecords({error,data}){
    if(data){
        this.data = data;
    }else if (error){
        this.data = undefined;
        }

    }

}