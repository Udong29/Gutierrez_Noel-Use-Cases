import { LightningElement } from 'lwc';
import firsthtml from './carwebcomp.html';
import secondhtml from './carlist.html';


export default class Carwebcomp extends LightningElement {

greeting;
template='first';

connectedCallback(){
    console.log('Connected Callback Ran');
}
constructor(){
    super();
    this.greeting = 'Good Morning';
    console.log('Constructor Loaded');
    this.template='first';
}

renderedCallback(){
    console.log('Rendered Callback Ran');
}


handleTemplate(){
    if(this.template ==='first'){
        this.template ='second';
        }else if(this.template==='second'){
            this.template='first';
        }
       
}

render(){
    console.log('Render Ran');
    if(this.template ==='first'){
        return firsthtml;
    }else if(this.template==='second'){
        return secondhtml;
    }

}


}


