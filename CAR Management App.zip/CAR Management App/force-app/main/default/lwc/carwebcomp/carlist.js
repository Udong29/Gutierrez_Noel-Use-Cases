import { LightningElement,wire,track } from 'lwc';


export default class CarList extends LightningElement {

  showImgContent(e) {
    for(var i = 0; i < imgContent.length; i++) {
      x = e.pageX;
      y = e.pageY;
      imgContent[i].style.transform = `translate3d(${x}px, ${y}px, 0)`;
    }
  }

}