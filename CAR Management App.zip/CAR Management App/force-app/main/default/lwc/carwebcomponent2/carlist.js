import { LightningElement } from 'lwc';
import cars from './carlist.html'

export default class carlist extends LightningElement {
    
    showImgContent(e) {
        for(var i = 0; i < imgContent.length; i++) {
          x = e.pageX;
          y = e.pageY;
          imgContent[i].style.transform = `translate3d(${x}px, ${y}px, 0)`;
        }
      }
   

}
    