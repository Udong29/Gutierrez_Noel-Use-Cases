import { LightningElement } from 'lwc';
import templateOne from './carwebcomponent2.html';
import templateTwo from './carlist.html';

export default class CarWebComponent2 extends LightningElement {

    templateOne = true;

    render() {
        return this.templateOne ? templateOne : templateTwo;
    }

    switchTemplate(){ 
        this.templateOne = this.templateOne === true ? false : true; 
    }
}