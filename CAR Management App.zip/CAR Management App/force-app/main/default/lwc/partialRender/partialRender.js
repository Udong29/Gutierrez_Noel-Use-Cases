import { LightningElement } from 'lwc';
import LAST_NAME from '@salesforce/schema/Lead.LastName';

export default class PartialRender extends LightningElement {

isShow = false;

handleClick(){
    if(this.isShow){
        this.isShow=false;
    }else{
        this.isShow=true;
    }
}




}